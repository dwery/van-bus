wmp=new ActiveXObject("wmpuice.wmpapp.1");
wmp.Open();
player=wmp.Core;
if (player.playstate==3) player.controls.pause();
else player.controls.play();